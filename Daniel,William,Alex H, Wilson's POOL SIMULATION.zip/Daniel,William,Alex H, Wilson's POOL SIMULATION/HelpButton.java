import greenfoot.*;

/**
 * Write a description of class HelpButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HelpButton extends Buttons
{
    Instruction3 instruction3 = new Instruction3();
    Instruction2 instruction2 = new Instruction2();
    Instruction1 instruction1 = new Instruction1();
    NextButton3 button3 = new NextButton3();
    NextButton2 button2 = new NextButton2();
    NextButton1 button1 = new NextButton1();
    
    public void clicked()
    {
        getWorld().addObject (instruction3, getWorld().getWidth()/2 , getWorld().getHeight()/2);
        getWorld().addObject (button3, 700 , 330);
        getWorld().addObject (instruction2, getWorld().getWidth()/2 , getWorld().getHeight()/2);
        getWorld().addObject (button2, 700 , 450);
        getWorld().addObject (instruction1, getWorld().getWidth()/2 , getWorld().getHeight()/2);
        getWorld().addObject (button1, 700 , 450);
    }
}
