import greenfoot.*;

/**
 * Game over screen of the game
 * Closing screen, contains button to return to main menu
 * 
 * @author Alex Huang
 * @version 1.0
 * 
 * -1.0 (Alex) Class was Created
 */
public class EndWorld extends World
{
    GreenfootSound backgroundMusic = new GreenfootSound("OSTover.mp3");
    RestartButton restartButton;
    private int actCount=0;
    
    /**
     * Constructor for MenuWorld() class
     * sets up world and places buttons and images on main screen
     */
    public EndWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(860, 560, 1); 
        //plays background music
        backgroundMusic.play();
        restartButton = new RestartButton();
    }
    
    public void act()
    {
        //spawns restart button after a short period of time
        actCount++;
        if (actCount>=500) addObject (restartButton, 700,400);
    }
    
    /**
     * Transistions into the main menu world
     */
    public void restart()
    {
        backgroundMusic.stop();
        World menuWorld = new MenuWorld();
        Greenfoot.setWorld(menuWorld); 
    }
}
