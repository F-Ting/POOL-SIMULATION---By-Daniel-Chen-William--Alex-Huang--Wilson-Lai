import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class AmountDisplay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ReputationDisplay extends Buttons
{
    private GreenfootImage myImage;
    private Font textFont;
    int amount=0;
    int newAmount;
    private String amountStr;
    
    MenuWorld menuWorld;
    
    public ReputationDisplay() 
    {
        amount=0;
        menuWorld = (MenuWorld) getWorld();
        
        myImage = new GreenfootImage(100,40);
        this.setImage(myImage);
        textFont = new Font ("Courier", Font.BOLD, 35);
       
        
        //amountStr = Integer.toString(amount);                 // cast the interger minutes into a string and store it in minutesStr
        //myImage.drawString(amountStr , 20,20);
    }    
    
    public void act() 
    {
        menuWorld = (MenuWorld) getWorld();
        newAmount = menuWorld.getRepPercent();
        if (newAmount != amount)
        {
            amount = newAmount;
            myImage.clear();
        }
        amountStr = Integer.toString(amount);  
        
        myImage.setFont(textFont);
        myImage.setColor(Color.BLACK);// cast the interger minutes into a string and store it in minutesStr
        myImage.drawString(amountStr , 40,40);
    }
}
