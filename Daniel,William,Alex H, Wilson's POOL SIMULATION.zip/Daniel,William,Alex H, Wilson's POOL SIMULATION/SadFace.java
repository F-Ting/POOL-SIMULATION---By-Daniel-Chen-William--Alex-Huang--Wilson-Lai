import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * HappyFace class is used to show the unsatisfaction when the someone leaves or drowns.
 * 
 * @author (Daniel) 
 * @version 1.1
 * -1.0 (Wilson) made the images
 * -1.1 (Daniel) Fade away when image created
 */
public class SadFace extends Misc
{
    public SadFace()
    {
        getImage().scale(30,30);
    }

     /**
     * moving up slowly and fading away unitl it disappears
     */
    public void act() 
    {
        setLocation(getX(),getY() - 1);
        if(getImage().getTransparency() > 10)
            getImage().setTransparency(getImage().getTransparency() - 1);
        if(getY() <= 0)
            getWorld().removeObject(this);
    }    
}
