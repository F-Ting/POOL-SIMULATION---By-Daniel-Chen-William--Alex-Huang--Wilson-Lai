import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * This class uses 50 syllables and selection a few randomly to make up a random name.
 * 
 * @author Daniel
 * @version 1.0
 * - 1.0 Returns a name 
 */
public class Name extends Misc
{
    private GreenfootImage myImage;
    private String name = "";

    public Name()
    {
        name(Greenfoot.getRandomNumber(2)+2);
    }

    /**
     * return a word made up of 1-4 syllables.
     * 
     * @param numSyl a number between 1-4
     * 
     */
    private void name(int numSyl)
    {
        if (numSyl > 0 && numSyl <= 4)
        {
            for (; numSyl > 0; numSyl --)
            {
                name +=  chooseSyl(Greenfoot.getRandomNumber(49));
            }
        }
    }

    /**
     * return a syllable based on a number
     * 
     * @param numSyler a number between 0-49
     * @return syllable a syllable based on the number from parameter
     */
    private String chooseSyl(int numSylber)
    {
        if (numSylber == 0)
        {
            return "ab";
        }
        else if (numSylber == 1)
        {
            return "bim";
        }
        else if (numSylber == 2)
        {
            return "la";
        }
        else if (numSylber == 3)
        {
            return "a";
        }
        else if (numSylber == 4)
        {
            return "ka";
        }
        else if (numSylber == 5)
        {
            return "dii";
        }
        else if (numSylber == 6)
        {
            return "po";
        }
        else if (numSylber == 7)
        {
            return "i";
        }
        else if (numSylber == 8)
        {
            return "ga";
        }
        else if (numSylber == 9)
        {
            return "ka";
        }
        else if (numSylber == 10)
        {
            return "ki";
        }
        else if (numSylber == 11)
        {
            return "gir";
        }
        else if (numSylber == 12)
        {
            return "lei";
        }
        else if (numSylber == 13)
        {
            return "le";
        }
        else if (numSylber == 14)
        {
            return "lar";
        }
        else if (numSylber == 15)
        {
            return "gu";
        }
        else if (numSylber == 16)
        {
            return "gi";
        }
        else if (numSylber == 17)
        {
            return "da";
        }
        else if (numSylber == 18)
        {
            return "kir";
        }
        else if (numSylber == 19)
        {
            return "khu";
        }        
        else if (numSylber == 20)
        {
            return "puu";
        }
        else if (numSylber == 21)
        {
            return "ne";
        }
        else if (numSylber == 22)
        {
            return "sar";
        }        
        else if (numSylber == 23)
        {
            return "la";
        }        
        else if (numSylber == 24)
        {
            return "sii";
        }
        else if (numSylber == 25)
        {
            return "duu";
        }
        else if (numSylber == 26)
        {
            return "li";
        }
        else if (numSylber == 27)
        {
            return "gur";
        }
        else if (numSylber == 28)
        {
            return "rir";
        }
        else if (numSylber == 29)
        {
            return "mash";
        }
        else if (numSylber == 30)
        {
            return "lan";
        }
        else if (numSylber == 31)
        {
            return "kim";
        }
        else if (numSylber == 32)
        {
            return "jun";
        }
        else if (numSylber == 33)
        {
            return "il";
        }
        else if (numSylber == 34)
        {
            return "dan";
        }
        else if (numSylber == 35)
        {
            return "gas";
        }
        else if (numSylber == 36)
        {
            return "jam";
        }
        else if (numSylber == 37)
        {
            return "jan";
        }
        else if (numSylber == 38)
        {
            return "lou";
        }
        else if (numSylber == 39)
        {
            return "don";
        }
        else if (numSylber == 40)
        {
            return "rak";
        }        
        else if (numSylber == 41)
        {
            return "sai";
        }        
        else if (numSylber == 42)
        {
            return "kat";
        }
        else if (numSylber == 43)
        {
            return "cai";
        }        
        else if (numSylber == 44)
        {
            return "shar";
        }
        else if (numSylber == 45)
        {
            return "gig";
        }
        else if (numSylber == 46)
        {
            return "jon";
        }
        else if (numSylber == 47)
        {
            return "than";
        }
        else if (numSylber == 48)
        {
            return "bard";
        }
        else if (numSylber == 49)
        {
            return "gnar";
        }
        else if (numSylber == 50)
        {
            return "fiz";
        }
        return "gus";
    }

    public String getName()
    {
        return name;
    }
}
