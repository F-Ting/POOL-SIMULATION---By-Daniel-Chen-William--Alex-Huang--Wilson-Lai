import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Creates an object that displace the stats of a clicked People object and the image of said People object inside a box.
 * 
 * @author (William)
 * @version 1.2
 * -1.0 (William) created class with basic outline and update
 * -1.1 (William) added update class for null and added methods: setRef and nullRef
 * -1.2 (William) relocated code into method draw() and changed background color
 */
public class ObjectInfo extends HUD
{
    private GreenfootImage canvas;      //canvas (whole)
    private GreenfootImage img;         //canvas (Immage)
    private int speed;
    private String speedInfo;
    private int stamina;
    private String staminaInfo;
    private String statusInfo;
    private String status;
    private String nameInfo;
    private String name;
    private String typeInfo;
    private String type;
    private boolean pplSel = false;     //has People reference
    private People ref;
    /**
     * Constructs an People information display that shows the image, stamina, speed, Name, status, and type of the
     * People class clicked.
     */
    public ObjectInfo()
    {
        //sets canvas for this object
        canvas = new GreenfootImage(200,100);
        canvas.setColor(Color.RED);
        canvas.fill();
        //sets small canvas inside for image of People
        img = new GreenfootImage(80,80);
        img.setColor(Color.WHITE);
        img.fill();
        canvas.drawImage(img,10,10);
        //sets text
        speedInfo = "Speed: ";
        staminaInfo = "Stamina: ";
        statusInfo = "Status: ";
        nameInfo = "Name: ";
        typeInfo = "Type: ";
        //draws text
        canvas.setColor(Color.WHITE);
        canvas.drawString(nameInfo,100,20);
        canvas.drawString(statusInfo,100,37);
        canvas.drawString(staminaInfo,100,54);
        canvas.drawString(speedInfo,100,70);
        canvas.drawString(typeInfo,100,86);

        this.setImage(canvas);
    }

    /**
     * draws ObjectInfo for a image that has no reference People class to refer to.
     */
    public void update()
    {
        canvas.clear();
        canvas.setColor(Color.RED);
        canvas.fill();

        img = new GreenfootImage(80,80);
        img.setColor(Color.WHITE);
        img.fill();
        canvas.drawImage(img,10,10);

        speedInfo = "Speed: ";
        staminaInfo = "Stamina: ";
        statusInfo = "Status: ";
        nameInfo = "Name: ";
        typeInfo = "Type: ";

        canvas.setColor(Color.WHITE);
        canvas.drawString(nameInfo,100,20);
        canvas.drawString(statusInfo,100,37);
        canvas.drawString(staminaInfo,100,54);
        canvas.drawString(speedInfo,100,70);
        canvas.drawString(typeInfo,100,86);
    }

    /**
     * Sets values as the selected object and draws them accordingly.
     * 
     * @param object Object of People class whose stats will be shown
     */
    public void update(People object)
    {
        this.img = object.getImage();
        this.speed = object.getSpeed();
        this.stamina  = object.getStamina();
        this.status = object.getStatus();
        this.name = object.getName();
        this.type = object.getType();

        draw();
    }

    /**
     * draws current stats as text and image on canvas
     */
    private void draw()
    {
        canvas.clear();
        canvas.setColor(Color.RED);
        canvas.fill();

        img = new GreenfootImage(80,80);
        img.setColor(Color.WHITE);
        img.fill();
        img.drawImage(ref.getImage(),40-ref.getImage().getWidth()/2,40-ref.getImage().getHeight()/2);
        canvas.drawImage(img,10,10);

        speedInfo = "Speed: "+speed;
        staminaInfo = "Stamina: "+stamina;
        statusInfo = "Status: "+status;
        nameInfo = "Name: "+name;
        typeInfo = "Type: "+type;

        canvas.setColor(Color.WHITE);
        canvas.drawString(nameInfo,100,20);
        canvas.drawString(statusInfo,100,37);
        canvas.drawString(staminaInfo,100,54);
        canvas.drawString(speedInfo,100,70);
        canvas.drawString(typeInfo,100,86);
    }

    /**
     * Sets the input as the reference object where the stats are gathered from.
     * 
     * @param ref object whose stats are used
     */
    public void setRef(People ref)
    {
        this.ref = ref;
    }

    /**
     * use this right before you remove an object
     */
    public void nullRef()
    {
        ref = null;
    }

    /**
     * constantly updates stats with the reference object if there is one and with a blank layout if there is no
     * reference.
     */
    public void act() 
    {
        if(ref != null){
            pplSel = true;
        }else{
            pplSel = false;
        }

        if(pplSel){
            update(ref);
        }else{
            update();
        }

        if(Greenfoot.mouseClicked(null)){
            ref = null;
        }
    }    
}
