import greenfoot.*;

/**
 * Write a description of class SettingButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SettingButton extends Buttons
{
    Setting page = new Setting();
    
    PlusAmount plusAmount = new PlusAmount();
    MinusAmount minusAmount = new MinusAmount();
    PlusSpeed plusSpeed = new PlusSpeed();
    MinusSpeed minusSpeed = new MinusSpeed();
    PlusRep plusRep = new PlusRep();
    MinusRep minusRep = new MinusRep();
    
    AmountDisplay amountDisplay = new AmountDisplay();
    SpeedDisplay speedDisplay = new SpeedDisplay();
    ReputationDisplay reputationDisplay = new ReputationDisplay();
    
    StartButton button = new StartButton();
    
    public void clicked()
    {
        getWorld().addObject (page, getWorld().getWidth()/2 , getWorld().getHeight()/2);
        
        getWorld().addObject (plusAmount, 250 , 340);
        getWorld().addObject (minusAmount, 150 , 340);
        getWorld().addObject (plusSpeed, 475 , 340);
        getWorld().addObject (minusSpeed, 375 , 340);
        getWorld().addObject (plusRep, 700 , 340);
        getWorld().addObject (minusRep, 600 , 340);
        
        getWorld().addObject (button, 650 , 440);
        
        getWorld().addObject (amountDisplay, 200 , 270);
        getWorld().addObject (speedDisplay, 425 , 270);
        getWorld().addObject (reputationDisplay, 640 , 270);
    }
}
