import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * People is the main actors in this simulation that almost interacts with everything. As for the simulation, people are the elements in making it interesting.
 * As the Simulation starts, first people would come out of the change room and select one of the 3 objects to goto(2 of which are linked together, diving board and pool). 
 * After selecting the object, the people would head towards the object, upon coming intouch with another pool object in it's way, it would look for a closest path toward it's target.
 * When the person has reaches the targeted pool object, it would first check for is the pool object is available by getting it's access, if so, it would choose one of the three following actions to do.
 * 1.Swiming - this is when the person targets the pool and reaches the pool, the person will slow down and swim around the pool while their stamina decrease over time
 * 2.Jumping - this is when the person targets the diving board and reaches the diving board, the person will follow a designed path to jump from the diving board into the pool;
 * 3.FindSpot - this is when the person targets the hot tub and reaches the hot tub, the person would look for a spot if available, if so it would go to the spot and chill there for a while.
 * When the person reaches below a certain stamina, they get tired and leaves. If the person is swimming however, and they doesn't get out of the pool before their stamina gets too low,
 * they'll start drowning. Once someone is drowning, an icon appears on top of the person. One of the 2 following happens
 * 1. If they get saved by a life guard, the person gets healed and move towards a location then leaves.
 * 2. The lifegurad doesn't reach the person in time and they drown.
 * Whenever a person leaves from the world, a update message will show up of either drowning or leaving.
 * 
 * @author Daniel Chen 
 * @version 2.1
 * -1.0 (Daniel) Class was Created
 * -1.1 (Daniel) Spawn and Drown notifications
 * -1.2 (Wilson) Choose Destination when spawned and walk to destination (Walk and Destination Method)
 * -1.3 (Daniel) stamina, currentStamina and staminaPercent
 * -1.4 (Daniel) play, jump,swim and turnRandomly methods
 * -1.5 (William) relax method
 * -1.6 (Daniel) isDrowning, checkDrown, walk and destination method
 * -1.7 (Daniel) tired and heal method
 * -1.8 (Daniel,Wilson,Alex) SplashImages and Sound
 * -1.9 (William) checkID method
 * -2.0 (Daniel) accessors
 * -2.1 (Alex) carry method
 */
public abstract class People extends Actor
{
    // initialize these values in the subclass
    protected int startSpeed;
    protected int speed;
    protected int chanceOfDrowning;
    protected int stamina;
    protected int currentStamina;
    protected int staminaPercent;
    protected int randomize;
    protected int myWidth;
    protected String type;
    protected String myName;
    protected String status; 
    protected String currentTarget;
    private int targetLocationX;
    private int targetLocationY;
    private int imageWidth;
    private int imageHeight;

    protected boolean spawned;
    protected boolean spotFound;
    protected boolean willToLeave;
    protected boolean arrived;
    protected boolean destinationChanged;
    protected boolean hasBeenToPool;
    protected boolean hasBeenToBoard;
    protected boolean hasBeenToTub;
    protected boolean isDrowning;
    protected boolean leave;
    private boolean findingSpot;
    private boolean dived;
    private boolean checkPosition;
    private boolean detour;
    private boolean hasID;
    private boolean north;
    private boolean east;
    private boolean south;
    private boolean west;
    private boolean arrayChange;

    private ObjectInfo ref;
    protected Name n;
    private Actor target;
    private Actor pool;
    private Splash splash;
    private Help help;
    private Died died;
    private PoolObjects touchingObject;
    private Heal heal;
    GreenfootSound splashMusic = new GreenfootSound("splash.wav") ;
    GreenfootSound healMusic = new GreenfootSound("heal.mp3.mp3") ;
    /**
     * create name for person spawned, and set spawned to true
     * 
     */
    public People()
    {
        n = new Name();                     // create a name for the people
        myName = n.getName();               // set the name for people
        help = new Help();
        heal = new Heal();
        died = new Died();
        splash = new Splash();
        spawned = true;                     // people has spawned
        imageWidth = getImage().getWidth();
        imageHeight = getImage().getHeight();
    }

    /**
     * shows who has joined to swim
     * 
     */
    protected void spawnedNotification()
    {
        status = "walking";

        if(spawned)
        {
            getWorld().addObject(help,0,0);
            help.getImage().setTransparency(0);
            MillikenWorld m = (MillikenWorld)getWorld();
            m.updateNews(myName + " has joined");
            spawned = false;
            destination();
        }
    }

    /**
     * if he person is currently drowning.
     * 
     */
    protected boolean isDrowning()
    {
        pool = (Actor)getWorld().getObjects(Pool.class).get(0);
        if(status == "Saved")
        {
            speed = startSpeed;
            help.getImage().setTransparency(0);
            status = "rescued";
            return false;
        }
        else if((getX() > pool.getX() - pool.getImage().getWidth()/2  + 5 && getX() < pool.getX() + pool.getImage().getWidth()/2  - 5 &&  getY() >=pool.getY() - pool.getImage().getHeight()/2 +  5 && getY() < pool.getY() + pool.getImage().getHeight()/2 - 5) && (staminaPercent <= 15)) //|| isDrowning == true))
        {
            speed = 0;
            currentStamina -= 3;
            status = "Drowning";
            help.setLocation(getX(),getY()-30);
            help.getImage().setTransparency(255);
            if (staminaPercent <= 0 || currentStamina <= 0)
            {
                if(getImage().getWidth() > 1 && getImage().getHeight() > 1)
                    getImage().scale(getImage().getWidth()-1, getImage().getHeight() -1);
                else
                {
                    getWorld().addObject(died,getX(),getY()-30);
                    drownNotification();
                }
            }
            return true;
        }
        return false;
    }

    protected void checkDrown()
    {
        if (Greenfoot.getRandomNumber(chanceOfDrowning) == 0)
            isDrowning = true;
    }

    /**
     * Walk towards current target while decreasing stamina.
     */
    protected void walk()
    {
        if(isTouching(PoolObjects.class) == false)
            speed = startSpeed;
        if(detour == false)
        {
            turnTowards(target.getX(),target.getY());
        }
        move(speed);
        if(willToLeave == false)
            headingToward();
        if(getX() >= 490 && getX() <= 500 && getY() >= 20 && getY() <= 25  && willToLeave == true)
            leaveNotification();
        currentStamina -= 2;
    }

    /**
     * Chooses a random pool object to go to, set the current target as the location it is heading.
     */
    private void destination()
    {
        randomize = Greenfoot.getRandomNumber(3);
        if (randomize == 0 && hasBeenToPool == false)
        {
            currentTarget = "pool";
            target = (Actor)getWorld().getObjects(Pool.class).get(0);
        }
        else if (randomize == 1 && hasBeenToBoard == false)
        {
            currentTarget = "diving board";
            target = (Actor)getWorld().getObjects(Board.class).get(0);
        }
        else if (randomize == 2 && hasBeenToTub == false)
        {
            currentTarget = "hot tub";
            target = (Actor)getWorld().getObjects(HotTub.class).get(0);
        }
        else if (hasBeenEveryWhere())
        {
            leave();
            detour = false;
        }

    }

    /**
     * if all pool objects has been to.
     */
    protected boolean hasBeenEveryWhere()
    {
        if (hasBeenToPool == true && hasBeenToBoard == true && hasBeenToTub == true)
            return true;
        return false;
    }

    /**
     * heading toward a pool object, if the pool object is full, head somewhere else
     */
    private void headingToward()
    {
        touchingObject = (PoolObjects)getOneObjectAtOffset(1, 0, PoolObjects.class);
        if (touchingObject != null){
            if (isTouching(Pool.class))
            {
                if(currentTarget == "pool")
                {
                    hasBeenToPool = true;
                    if(touchingObject.getAccess() == true)
                    {
                        arrived = true;
                        detour = false;
                    }
                    if(arrived == false)
                    {
                        destination();
                    }
                }
                else 
                    goAround();
            }
            else if (isTouching(Board.class)){
                if (currentTarget == "diving board")
                {
                    hasBeenToBoard = true;
                    if(touchingObject.getAccess() == true)
                    {
                        arrived = true;
                        detour = false;
                    }
                    if(arrived == false)
                    {
                        destination();
                    }
                }
                else
                    goAround();
            }
            else if (isTouching(HotTub.class)){
                if (currentTarget == "hot tub")
                {
                    hasBeenToTub = true;
                    if(touchingObject.getAccess() == true)
                    {
                        arrived = true;
                        detour = false;
                    }
                    if(arrived == false)
                    {
                        destination();
                    }
                }
                else
                    goAround();
            }
        }
        if (touchingObject == null)
            detour = false;
    }

    /**
     * if arrived at the target object
     */
    protected boolean arrived()
    {
        if (currentTarget == "pool" && arrived == true)
            return true;
        else if (currentTarget == "diving board" && arrived == true)
            return true;
        else if (currentTarget == "hot tub" && arrived == true)
            return true;
        else
            return false;
    }

    /**
     * head toward the changeRoom
     */
    protected void leave()
    {
        getWorld().removeObject(heal);
        arrived = false;
        currentTarget = "change room";
        target = (Actor)getWorld().getObjects(ChangeRoom.class).get(0);
        willToLeave = true;
    }

    /**
     * set status as swimming and swim
     */
    private void swim()
    {
        status = "Swimming";
        speed = 1;
        move(speed);
        if(getImage().getWidth() > imageWidth && getImage().getHeight() > imageHeight)
            getImage().scale( getImage().getWidth() - 1, getImage().getHeight() - 1);
        else if(splash.getImage().getWidth() > getImage().getWidth() && splash.getImage().getWidth() > getImage().getHeight())
        {
            splash.getImage().scale(splash.getImage().getWidth() -3,splash.getImage().getHeight() -3);
        }
        else
            getWorld().removeObject(splash);
        if(getX() > target.getX() - target.getImage().getWidth()/2 + 10 && getX() < target.getX() + target.getImage().getWidth()/2  - 10 &&  getY() >=target.getY() - target.getImage().getHeight()/2 + 10 && getY() < target.getY() + target.getImage().getHeight()/2 - 10)
        {
            if(isTouching(Board.class))
            {
                turn(180);
                if(getY() < 265)
                    this.setLocation(getX(), getY() - 1);
                else
                    this.setLocation(getX(), getY() + 1);
            }else
                turnRandomly();
        }
        else
            turnTowards(target.getX(),target.getY());

        currentStamina -= 2;
    }

    /**
     * do things depending on which pool object the person is currently at
     * if at pool, then swim
     * if at diving board, then jump into pool
     * if at hot tub, then relax
     */
    protected void play()
    {
        if (currentTarget == "pool" && arrived == true)
            swim();    
        else if (currentTarget == "diving board" && arrived == true)
            jump();    
        else if (currentTarget == "hot tub" && arrived == true)
            relax();
    }

    /**
     * if get access is true, find a spot and relax
     */
    private void relax()
    {
        HotTub ht = (HotTub)getOneIntersectingObject(HotTub.class);
        if (findingSpot == false)
        {
            spotFound = ht.getAccess();
            findingSpot = true;
        }
        if(spotFound)
        {
            status = "Chilling";
            currentStamina -= 1;
            if(!arrayChange)
            {
                ht.addToList(this);
                arrayChange = true;
            }
        }else{
            status = "Finding Spot";
            currentStamina -= 1;
        }
    }

    /**
     * goes on a detour to get to the target location
     */
    private void goAround()
    {
        detour = true;
        if(checkPosition == false)
        {
            checkTargetPosition();
            checkPosition = true;
        }

        if(getX() < touchingObject.getX() - touchingObject.getWidth()/2) // if is approching touchingObject from the left
        {
            if(north == true) // if target is on the north side
            {
                targetLocationY = touchingObject.getY() - touchingObject.getImage().getHeight()/2;  // assuming the image is a rectangle or square, set targetLocationY as the most north point of the touchingObject 
                if(getY() >= targetLocationY)
                {
                    turnNorth();
                }
                else 
                    checkTargetPosition();
            }
            else // if target is on the south side
            {
                targetLocationY = touchingObject.getY() + touchingObject.getImage().getHeight()/2;  // assuming the image is a rectangle or square, set targetLocationY as the most south point of the touchingObject
                if(getY() < targetLocationY)
                {
                    turnSouth();
                }
                else 
                    checkTargetPosition();
            }
        }
        else if (getX() >= touchingObject.getX() - touchingObject.getWidth()/2 && getX() < touchingObject.getX() + touchingObject.getWidth()/2)   // if is approching touchingObject from up or down
        {
            if(east == true) // if target is on the east side
            {
                targetLocationX = touchingObject.getX() + touchingObject.getWidth()/2;  // assuming the image is a rectangle or square, set targetLocationY as the most east point of the touchingObject
                if(getX() <= targetLocationX + 30)
                {
                    turnEast();
                }
                else 
                    checkTargetPosition();
            }
            else // if target is on the west side
            {
                targetLocationX = touchingObject.getX() - touchingObject.getWidth()/2;  // assuming the image is a rectangle or square, set targetLocationY as the most west point of the touchingObject
                if(getX() >= targetLocationX)
                {
                    turnWest();
                }
                else 
                    checkTargetPosition();
            }
        }
        else if (getX() >= touchingObject.getX() + touchingObject.getWidth()/2) // if is approching touchingObject from the left
        {
            if(north == true) // if target is on the north side
            {
                targetLocationY = touchingObject.getY() + touchingObject.getImage().getHeight()/2;
                if(getY() < targetLocationY)
                {
                    turnNorth();
                }
                else 
                    checkTargetPosition();
            }
            else // if target is on the south side
            {
                targetLocationY = touchingObject.getY() - touchingObject.getImage().getHeight()/2;
                if(getY() >= targetLocationY)
                {
                    turnSouth();
                }
                else 
                    checkTargetPosition();
            }
        }
    }

    /**
     * check the target position when making a detour
     */
    private void checkTargetPosition()
    {
        if (target.getX() >= getX())
        {
            east = true;
            west = false;
        }
        else 
        {
            west = true;
            east = false;
        }

        if (target.getY() >= getY())
        {
            south = true;
            north = false;
        }
        else 
        {
            north = true;
            south = false;
        }
    }

    /**
     * turn north
     */
    private void turnNorth()
    {
        turnTowards(getX() ,getY() - 5);
    }

    /**
     * turn east
     */
    private void turnEast()
    {
        turnTowards(getX()+ 5 ,getY());
    }

    /**
     * turn south
     */
    private void turnSouth()
    {
        turnTowards(getX() ,getY() + 5);
    }

    /**
     * turn west
     */
    private void turnWest()
    {
        turnTowards(getX() - 5,getY());
    }

    /**
     * find a spot in the hot tub that doesn't overlap with another person
     * 
     */
    private void findSpot()
    {
        if(spotFound == false && isTouching(People.class) == false)
        {
            spotFound = true;
            speed = 0;
        }

    }

    /**
     * when stamina is below a percent
     */
    protected boolean tired()
    {

        if(staminaPercent < 20)
        {
            HotTub ht = (HotTub)getOneIntersectingObject(HotTub.class);
            if(isTouching(HotTub.class))
                ht.removeFromList(this);
            return true;
        }
        return false;
    }

    /**
     * get on the diving board and jump into the pool
     * 
     */
    private void jump()
    {
        status = "Diving";
        move(speed);
        if(getY() < 297)
        {
            turnSouth();
        }
        else if (getX() < 665 && getX() > 659)
        {
            getImage().scale(getImage().getWidth()+1, getImage().getHeight() +1);
        }
        else if (isTouching(Board.class))
        {
            turnWest();
        }
        else if (!isTouching(Board.class))
        {
            getWorld().addObject(splash,getX(),getY());
            splashMusic.play();
            currentTarget = "pool";
            target = (Actor)getWorld().getObjects(Pool.class).get(0);
        }
        currentStamina -= 5;
    }

    /**
     * if the mouse is over the person, get their information
     */
    protected void checkID()
    {
        if(Greenfoot.mouseClicked(this)){
            ref.setRef(this);
        }
        if(!hasID){
            this.ref = (ObjectInfo)getOneObjectAtOffset(-this.getX()+770,-this.getY()+520,ObjectInfo.class);
            hasID = true;
        }
    }

    /**
     * shows who has drowned and decrease reputation
     */
    protected void drownNotification()
    {
        MillikenWorld m = (MillikenWorld)getWorld();
        m.updateNews(myName + " has drowned");
        m.updateReputation(-10);
        getWorld().removeObject(help);
        getWorld().removeObject(this);
    }

    /**
     * shows who has left and change reputation based on if they are satisfied or not
     */
    private void leaveNotification()
    {
        MillikenWorld m = (MillikenWorld)getWorld();
        m.updateNews(myName + " has left");
        if(staminaPercent > 30)
            m.updateReputation(-8);
        else 
            m.updateReputation(1);
        getWorld().removeObject(help);
        leave = true;
        getWorld().removeObject(this);
    }

    /**
     * turn randomly
     */
    private void turnRandomly ()
    {
        if (Greenfoot.getRandomNumber (200) == 50)
        {
            turn (Greenfoot.getRandomNumber(360));
        }
    }

    /**
     * @param x the x coordinate to set the person at
     * @param y the y coordinate to set the person at
     */
    public void carry(int x, int y)
    {
        arrived = false;
        this.setLocation(x,y);
    }

    /**
     * @param staminaPercent get the person's stamina in percent
     */
    public int getStamina()
    {
        return staminaPercent;
    }

    /**
     * @param speed get the person's speed
     */
    public int getSpeed()
    {
        return speed;
    }

    /**
     * @param status get the person's status
     */
    public String getStatus()
    {
        return status;
    }

    /**
     * @param type get the person's type
     */
    public String getType()
    {
        return type;
    }

    /**
     * @param myName get the person's name
     */
    public String getName()
    {
        return myName;
    }

    /**
     * heals the person
     */
    public void heal()
    {
        healMusic.play();
        getWorld().addObject(heal,getX(),getY());
        heal.setLocation(getX(),getY()- 20);
        heal.getImage().scale(20,20);
        speed = startSpeed;
        currentStamina = 1000;
        isDrowning = false;
        help.getImage().setTransparency(0);
    }

    /**
     * @param stat, sets the status of the person
     */
    public void setStatus(String stat)
    {
        this.status = stat;
    }
}

