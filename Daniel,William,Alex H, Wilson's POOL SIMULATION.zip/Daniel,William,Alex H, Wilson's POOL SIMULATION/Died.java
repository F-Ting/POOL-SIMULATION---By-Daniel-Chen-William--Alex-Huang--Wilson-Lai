import greenfoot.*;

/**
 * Write a description of class Died here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Died extends JustImages
{
    private int counter = 0;
    /**
     * Act - do whatever the Died wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Died()
    {
        this.getImage().scale(30,40);
    }
    public void act() 
    {
        counter++;
        if (counter >300) getWorld().removeObject(this);
    }    
}
