import greenfoot.*;

/**
 * Parent class to contain images for the buttons in the instruction page
 * 
 * @author Alex Huang
 * @version 1.0
 * 
 * -1.0 (Alex) Class was Created
 */
public abstract class Instructions extends Actor
{
    /**
     * Act - do whatever the Instructions wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
