import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HotTub here.
 * 
 * @author Wilson, Daniel, William
 * @version 1.4
 * -1.0 (Daniel) created class
 * -1.1 (Wilson) added image and animated steam
 * -1.2 (Daniel) added methods to check occupant
 * -1.3 (William) added method to move occupants to their location
 * -1.4 (William) fixed bug with moving kids to location
 */
public class HotTub extends PoolObjects
{
    private String image[] = {"hotTub.png","hotTub2.png","hotTub3.png","hotTub4.png", "hotTub5.png", "hotTub6.png", "hotTub7.png", "hotTub8.png", "hotTub9.png", "hotTub10.png"};
    private int frameCount;
    private int counter;
    /**
     * Constructs HotTub object with max limit of imput.
     * 
     * @param limit max limit of this object
     */
    public HotTub(int limit)
    {
        // The max amount of people 
        super(limit);
        frameCount = 0;
        counter = 0;
    }

    /**
     * Moves occupants in arrays to where they need to be, checks if the object is full, animates.
     */
    public void act() 
    {
        checkFull();
        getCurrentAmount();
        moveOccupants();
        animate();
    }    

    protected void getCurrentAmount()
    {
        int counter = 0;
        for(int i = 0;i<maxCapacity;i++){
            if(pList[i] != null){
                counter++;
            }
        }
        currentAmount = counter;
    }
    /**
     * Animates this object with the set images by switching between images at set intervals.
     */
    public void animate() 
    {
        counter++;
        if (counter % 5 == 0) frameCount++;
        if (frameCount > 9) frameCount = 0;
        if (counter > 100) counter =0;
        this.setImage(image[frameCount]);
    }

    /**
     * moves Occupants (objects in array) to preset positions.
     */
    private void moveOccupants(){
        //if this array index is not empty
        if(pList[0] != null){
            //if object has reach the position turn towards it and move
            if(pList[0].getX() != getX() && pList[0].getY() != getY()-40){
                pList[0].turnTowards(getX(),getY()-40);
                pList[0].move(1);
            }else{
                //if object has reach position turn towards center of pool
                pList[0].turnTowards(getX(),getY());
            }
        }
        if(pList[1] != null){
            if(pList[1].getX() != getX()+33){
                pList[1].turnTowards(getX()+33,getY()-23);
                pList[1].move(1);
            }else{
                pList[1].turnTowards(getX(),getY());
            }
        }
        if(pList[2] != null){
            if(pList[2].getX() != getX()+40 && pList[2].getY() != getY()+15){
                pList[2].turnTowards(getX()+40,getY()+15);
                pList[2].move(1);
            }else{
                pList[2].turnTowards(getX(),getY());
            }
        }
        if(pList[3] != null){
            if(pList[3].getX() != getX()+20 && pList[3].getY() != getY()+43){
                pList[3].turnTowards(getX()+20,getY()+43);
                pList[3].move(1);
            }else{
                pList[3].turnTowards(getX(),getY());
            }
        }
        if(pList[4] != null){
            if(pList[4].getX() != getX()-20 && pList[4].getY() != getY()+43){
                pList[4].turnTowards(getX()-20,getY()+43);
                pList[4].move(1);
            }else{
                pList[4].turnTowards(getX(),getY());
            }
        }
        if(pList[5] != null){
            if(pList[5].getX() != getX()-40 && pList[5].getY() != getY()+15){
                pList[5].turnTowards(getX()-40,getY()+15);
                pList[5].move(1);
            }else{
                pList[5].turnTowards(getX(),getY());
            }
        }
        if(pList[6] != null){
            if(pList[6].getX() != getX()-33){
                pList[6].turnTowards(getX()-33,getY()-23);
                pList[6].move(1);
            }else{
                pList[6].turnTowards(getX(),getY());
            }
        }
    }
}