import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Do what they do based on their current status and target(Described in superclass)
 * 
 * @author Daniel
 * @version 1.0
 *  1.0 class created
 */
public class Adult extends People
{

    public Adult()
    {
        super();
        startSpeed = 2;
        speed = startSpeed;
        stamina = 15000;
        chanceOfDrowning = 3000;
        currentStamina = stamina;
        type = "Adult";
    }

   /**
     * Spawn and updates current stamina percent as stamina decreases.
     */
    public void act() 
    {
        spawnedNotification();
        staminaPercent = (int)((double)currentStamina/stamina*100);
        checkDrown();
        if(tired())
            leave();
        if(arrived() == false)
            walk();
        else
            play();
        if (leave == false)
        {
            if(isDrowning())
                isDrowning = true;
        }
        checkID();
    }    
}
