import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Used to measure the time that has passed by using an act counter and changing the value at normal speed such that it mimics the time in real life.
 * 
 * @author (Daniel & William) 
 * @version March 31st
 */
public class Time extends HUD
{
    private GreenfootImage myImage;

    private Font textFont;

    private int actCounter ;
    private int minutes = 0;
    private int hours = 0;
    private int days = 0;

    private String minutesStr;
    private String hoursStr;
    /**
     * Constructs the Time measurement object and draws it.
     */
    public Time()
    {
        myImage = new GreenfootImage(100,40);
        this.setImage(myImage);
        textFont = new Font ("Courier", Font.BOLD, 24);
        myImage.setFont(textFont);
        myImage.setColor(Color.BLACK);
        minutesStr = Integer.toString(minutes);
        hoursStr = Integer.toString(hours);                 // cast the interger minutes into a string and store it in minutesStr
        myImage.drawString("0:00" , 20,20);
    }

    /**
     * Updates the time that has passed each act and redraws to reflect.
     */
    private void updateTime()
    {
        if ((actCounter % 62) == 0)
        {
            minutes ++;
            if (minutes == 60)
            {
                minutes = 0;
                hours ++;
            }
            if (hours == 24)
            {
                hours = 0;
                days ++;
            }
            myImage.clear();                  // clears the image
            minutesStr = Integer.toString(minutes);
            hoursStr = Integer.toString(hours);// cast the interger minutes into a string and store it in minutesStr    
            if (minutes < 10)
                myImage.drawString(hours + ":0" + minutesStr, 20,20);
            else if (minutes >= 10)
                myImage.drawString(hours + ":" + minutesStr, 20,20);

        }

    }

    /**
     * Continually updates time.
     */
    public void act() 
    {
        actCounter++;
        updateTime();
    }    
}

