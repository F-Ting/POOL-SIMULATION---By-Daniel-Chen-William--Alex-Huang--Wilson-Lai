import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * Displays reputation in a percentage of current and maximum while changing colors of the text to reflect the interval (good,netural,bad) percentage is in, also draws faces based on
 * change in reputation.
 * 
 * @author (William Zhen,Daniel,Wilson) 
 * @version 1.0
 * -1.0 (William) created class ability to identify interval through inputed max and curent values
 * -1.1 (William) added update method
 * -1.2 (William) added added accessors and changed colors for clarity
 * -1.3 (Daniel) added methods for adding faces depending on update input
 * -1.4 (Wilson) added images for faces
 */
public class RepDisplay extends HUD
{
    private int reputation;     //current reputation nominal
    private int max;            //maximum reputation nominal
    private int intervalA;
    private int intervalB;
    private int i;                  //number to represent the current interval
    private GreenfootImage repCanvas;
    private GreenfootImage textDis;
    private Font textFont;
    private String repText;
    private Color[] repColors = {new Color(0,153,76),new Color(255,128,0),new Color(200,0,0)};  //array of colors corresponding to intervals
    private final Color TRANSPARENT = new Color(0,0,0,0);

    /**
     * Creates reputation display with a emote and percentage text right of it. Sets maximum reputation and current reputation to max.
     * 
     * @param   max maximum reputation
     */
    public RepDisplay(int max)
    {
        //sets maximum and where the colors and faces will change
        this.max = max;
        this.intervalA = max/3;
        this.intervalB = max/3 + max/3 + max%3;
        this.reputation = max;

        //creates the canvas and sets font type
        repCanvas = new GreenfootImage(200,100);
        textFont = new Font ("Courier",Font.BOLD, 24);
        repCanvas.setFont(textFont);

        interval();
        //         if(reputation > intervalB){
        //             i = 0;
        //         }else if(reputation > intervalA){
        //             i = 1;
        //         }else{
        //             i = 2;
        //         }
        repCanvas.setColor(repColors[i]);

        //draws current percentage
        repCanvas.drawString((int)(((double)reputation/max)*100)+"%",100,50);
        //         repCanvas.drawImage(faces[i],0,50);

        this.setImage(repCanvas);
    }

    /**
     * Creates reputation display with a emote and percentage text right of it. Sets maximum and current reputation.
     * 
     * @param max maximum reputation
     * @param reputation current reputation
     */
    public RepDisplay(int max, int reputation)
    {
        this.max = max;
        this.intervalA = max/3;
        this.intervalB = max/3 + max/3 + max%3;
        this.reputation = reputation;

        repCanvas = new GreenfootImage(200,100);
        textFont = new Font ("Courier",Font.BOLD, 24);
        repCanvas.setFont(textFont);

        interval();
        repCanvas.setColor(repColors[i]);

        repCanvas.drawString((int)(((double)reputation/max)*100)+"%",100,50);

        this.setImage(repCanvas);
    }

    /**
     * updates the image and value of reputation by adding the input.
     * 
     * @param reputation  adds to reputation
     */
    public void update(int reputation)
    {
        if(reputation > 0)
            satisfied();
        else 
            unsatisfied();
        this.reputation += reputation;

        //adds input to reputation, prevents reputation from going past the domain
        if(this.reputation > 100){
            this.reputation = 100;
        }else if(this.reputation < 0){
            this.reputation = 0;
        }

        interval();
        repCanvas.clear();

        repCanvas.setColor(repColors[i]);
        repCanvas.drawString((int)(((double)this.reputation/max)*100)+"%",100,50);
    }

    /**
     * Gets current percentage.
     */
    public int getPercentage(){
        return (int)(((double)this.reputation/max)*100);
    }

    /**
     * checks and returns number that reperesents the interval the reputation is in.
     * 
     * @return  number representation of interval
     */
    public int getReputation()
    {
        return reputation;
    }
    
    /**
     * draws satisfied face
     */
    private void satisfied()
    {
        getWorld().addObject(new HappyFace(),getX() - 40,getY());
    }

    /**
     * draws unsatisfied face
     */
    private void unsatisfied()
    {
        getWorld().addObject(new SadFace(),getX() - 40,getY());
    }

    /**
     * checks and returns number that reperesents the interval the reputation is in.
     * 
     * @return number representation of interval
     */
    private int interval()
    {
        if(reputation > intervalB){
            i = 0;
        }else if(reputation > intervalA){
            i = 1;
        }else{
            i = 2;
        }
        return i;
    }
}
