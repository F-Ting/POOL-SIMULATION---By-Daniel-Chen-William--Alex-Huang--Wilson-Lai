import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Basic class for Pool image and array functionalities
 * 
 * @author (Daniel,Alex)
 * @version 1.1
 * -1.0 (Daniel) created class and basic checkFull method
 * -1.1 (Alex) created images and method for animated water
 */
public class Pool extends PoolObjects
{
    private String image[] = {"pool1.png","pool2.png","pool3.png","pool4.png"};
    private int frameCount;
    private int counter;
    /**
     * Constructs a pool with max limit of input.
     * 
     * @param limit maximum limit
     */
    public Pool(int limit)
    {
        super(limit);
        frameCount = 0;
        counter = 0;
    }

    /**
     * Animates and checks if this is full.
     */
    public void act() 
    {
        checkFull();
        getCurrentAmount();
        animate();
    }    

    /**
     * animates this object.
     */
    public void animate() 
    {
        counter++;
        if (counter % 5 == 0) frameCount++;
        if (frameCount > 3) frameCount = 0;
        if (counter > 50) counter =0;
        this.setImage(image[frameCount]);
    }

    /**
     * get the current amount of people in pool
     */
    protected void getCurrentAmount()
    {
        currentAmount = getIntersectingObjects(People.class).size();
    }

}
