import greenfoot.*;

/**
 * Parent class for the buttons in the main menu, including the setting page
 * 
 * @author Alex Huang
 * @version 1.0
 * 
 * -1.0 (Alex) Class was Created
 */
public abstract class Buttons extends Actor
{
    GreenfootSound clickSound = new GreenfootSound("click.wav");

    /**
     * Act - do whatever the HelpButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkMouse();
    }    

    /**
     * Checks if the button is being pressed and plays click sound
     */
    private void checkMouse()
    {
        if(Greenfoot.mouseClicked(this)) 
        {
            clickSound.play();
            clicked();
        }
    }
    
    /**
     * to be overridden by it subclasses 
     */
    protected void clicked()
    {
    }
}