import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * EXTRA CREDIT GOES TO
 * - Alex Huanh for image and animation of pool and music throughout the whole simulation.
 * - Wilson for image and animation of hot tub and many small images through the simulation.
 * - William the detailed and neat HUD(Heads Up Display) modular methods to add extra awesome features into the simulation.
 * 
 * Main menu of the game
 * Opening screen, contains buttons to begin game, change game settings and show instructions
 * 
 * @author Alex Huang
 * @version 1.0
 * 
 * -1.0 (Alex) Class was Created
 */
public class MenuWorld extends World
{
    private int guardSpeed = 2;
    private int guardAmount = 1;
    private int repPercent = 50;
    GreenfootSound backgroundMusic = new GreenfootSound("OSTmenu.mp3");
    

    /**
     * Constructor for MenuWorld() class
     * sets up world and places buttons and images on main screen
     */
    public MenuWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(860, 560, 1); 
        prepare();
    }
    
    /**
     * sets swimming speed of the guards
     * 
     * @param   add True will increase the speed value whilst False will decrease it
     */
    public void changeSpeed(boolean add)
    {  
        if (add)
        {
            if (guardSpeed <4) guardSpeed++;
        }
        if (!add)
        {
            if (guardSpeed >1) guardSpeed--;
        }
    }

    /**
     * sets number of guards on patrol
     * 
     * @param   add True will increase the number of guards whilst False will decrease it
     */
    public void changeAmount(boolean add)
    {  
        if (add)
        {
            if (guardAmount <4) guardAmount++;
        }
        if (!add)
        {
            if (guardAmount > 0) guardAmount--;
        }
    }

    /**
     * sets initial reputation of pool
     * 
     * @param   add True will increase the initial reputation value in increments of 25%
     *              whilst False will decrease it in increments of 25%
     */
    public void changeRep(boolean add)
    {  
        if (add)
        {
            if (repPercent <100) repPercent+=25;
        }
        if (!add)
        {
            if (repPercent > 25) repPercent-=25;
        }
    }

    /**
     * Returns current setting of guard speed
     */
    public int getGuardSpeed ()
    {
        return guardSpeed;
    }

    /**
     * Returns current setting of guard amount
     */
    public int getGuardAmount()
    {
        return guardAmount;
    }

    /**
     * Returns current setting of guard initial reputation
     */
    public int getRepPercent ()
    {
        return repPercent;   
    }

    /**
     * Plays background music when program is run
     */
    public void started()
    {  
        backgroundMusic.play();
    }

    /**
     * Transistions into the main simulation world
     */
    public void beginSim()
    {  
        //Stops menu music
        backgroundMusic.stop();
        World mainWorld = new MillikenWorld(this.guardSpeed,this.guardAmount,this.repPercent);
        Greenfoot.setWorld(mainWorld); 
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        HelpButton helpbutton = new HelpButton();
        addObject(helpbutton, 668, 390);
        StartButton startbutton = new StartButton();
        addObject(startbutton, 671, 311);
        SettingButton settingbutton = new SettingButton();
        addObject(settingbutton, 681, 478);
        settingbutton.setLocation(671, 473);
        startbutton.setLocation(666, 305);
        helpbutton.setLocation(664, 386);
        settingbutton.setLocation(664, 467);
        startbutton.setLocation(724, 308);
        startbutton.setLocation(672, 297);
        helpbutton.setLocation(707, 390);
        startbutton.setLocation(704, 307);
        helpbutton.setLocation(697, 409);
        settingbutton.setLocation(686, 510);
        startbutton.setLocation(695, 322);
        startbutton.setLocation(660, 284);
        helpbutton.setLocation(680, 403);
        helpbutton.setLocation(379, 385);
        settingbutton.setLocation(661, 363);;
        helpbutton.setLocation(664, 441);
        helpbutton.setLocation(680, 475);
        settingbutton.setLocation(677, 375);
        startbutton.setLocation(678, 277);
        startbutton.setLocation(684, 277);
        settingbutton.setLocation(684, 376);
        helpbutton.setLocation(685, 472);
        MenuCharacters menucharacters = new MenuCharacters();
        addObject(menucharacters, 340, 401);
        menucharacters.setLocation(336, 394);
        MessageBox messagebox = new MessageBox();
        addObject(messagebox, 346, 302);
        messagebox.setLocation(282, 315);
        menucharacters.setLocation(336, 400);
    }
}
