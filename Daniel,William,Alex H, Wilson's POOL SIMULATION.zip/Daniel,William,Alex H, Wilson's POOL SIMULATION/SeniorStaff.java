import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Senior staff are the one who's sitting on the chair looking over the pool rather than patroling around.
 * the senior life guard has cone of vision longe enough to watch over most of the pool but has a narrower vision 
 * compared to the junior life guard.
 * 
 * @author (Wilson) 
 * @version 1.2
 * -1.1 (Wilson) guard Class added 
 * -1.2 (Alex) guard Class revised and finalized 
 */
public class SeniorStaff extends LifeGuard
{
    private boolean turnLeft;
    private boolean turnRight;
    public SeniorStaff(int guardSpeed)
    {
        patrol = getImage();
        rescue = new GreenfootImage("glowS.png");
        startSpeed = 2;
        speed = startSpeed;
        swimSpeed = guardSpeed; 
        turn(180);
    }

    /**
     * Act - do whatever the SeniorStaff wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (spawned == false) spawned();
        cone.setLocation (getX(), getY());
        cone.getImage().scale(1200,90);
        if (returnToPatrol == true) returnPatrol();
        checkDrown();
        if(!saving)
            guard();

    }    

    /**
     * The senior staff will turn their head left and right while in the same position, on the chair.
     * The movement of their head simulates scanning.
     */
    private void guard()
    {
        if(turnLeft == false)
        {
            if(getRotation() < 255)
            {
                turn(1);
                cone.turn(1);
            }
            else
                turnLeft = true;
        }
        else
        {
            if(getRotation() > 180)
            {
                turn(-1);
                cone.turn(-1);
            }
            else
                turnLeft = false;
        }
    }
}
