import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Basic Class for holding Board image and array
 * 
 * @author Daniel
 * @version 1.0
 * -1.0 (Daniel) created class and basic fuctions of checking amount of occupants
 */
public class Board extends PoolObjects
{
    /**
     * Constructs a Board Object with a max limit of the input.
     * 
     * @param limit maximum occupants
     */
    public Board(int limit)
    {
        super(limit);
    }

    /**
     * checks if this object is full.
     */
    public void act() 
    {
        checkFull();
        getCurrentAmount();
    }    


    protected void getCurrentAmount()
    {
        currentAmount = getIntersectingObjects(People.class).size();
    }

}
