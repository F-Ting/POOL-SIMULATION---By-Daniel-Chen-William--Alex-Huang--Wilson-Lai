import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The lifeguard plays a main role in the smulation as they are the ones who saves people.
 * The lifeguard starts by patrolling around the pool,by calling the inView method from viewCone, 
 * they get the person who is drowning and they would begin their rescue mission.
 * During the process of rescuing, the lifeguard swims towards the person that is drowning and quickly 
 * move them towards the dock. Once the person and the lifeguard has reached the doc, the person is healed and
 * leaves while the lifeguard goes back to patrolling.
 * 
 * @author (Daniel) 
 * @version 1.3
 * -1.0 (Daniel)Class Created
 * -1.1 (Alex) checkDrown, spawned, rescue and patrol method
 * -1.2 (Daniel) made changes to rescue and checkDrownig method due to change in viewCone class.
 * -1.3 (Alex) DrownNotification class
 */
public abstract class LifeGuard extends Actor
{
    // initialize these attributes in constructor
    protected int startSpeed;
    protected int speed;
    protected int swimSpeed;
    protected boolean spawned;
    protected boolean returnToPatrol; 
    protected boolean saving;
    protected boolean success;
    private boolean whistled;
    private int initialX;
    private int initialY;
    private int initialRotation;

    GreenfootImage rescue;
    GreenfootImage patrol;
    
    private String tempName;

    protected People p;
    protected ViewCone cone;
    GreenfootSound whistle = new GreenfootSound("whistle.wav") ;
    protected void spawned ()
    {
        spawned = true;
        success = false;
        cone = new ViewCone();
        getWorld().addObject(cone, getX(), getY());
        cone.setRotation(180);
        initialX = getX();
        initialY = getY();
        initialRotation = getRotation();
    }

    protected void checkDrown()
    {
        p = cone.inView();
        if (p != null)
            rescue(p);
        else if(saving)
        {
            returnToPatrol = true;
            if (success) rescueNotification(tempName);
            success = false;
        }
    }

    /**
     * goes toward the person drowning
     * 
     */
    protected void rescue(People targetPerson)
    {
        cone.getImage().setTransparency(0);
        saving = true;
        this.setImage(rescue);
        if(whistled == false)
        {
            whistle.play();
            whistled = true;
        }
        if (!intersects(targetPerson)) 
        {
            move (swimSpeed);
            turnTowards(targetPerson.getX(), targetPerson.getY());
        }
        else
        {
            turnTowards (297,127);
            move (swimSpeed);
            targetPerson.setStatus("Saved");
            targetPerson.carry (getX(),getY());
            if(getX() < 160)
                setLocation(getX() - 1, getY());
            else
            {
                tempName = targetPerson.getName();
                targetPerson.heal();
                success = true;
            }
        }
    }
    
    
    /** 
     * Updates the newsfeed box to show who has been rescued.
     */
   protected void rescueNotification(String tempName)
    {
        MillikenWorld m = (MillikenWorld)getWorld();
        m.updateNews(tempName + " is safe");
    }
    
    /**
     * create an adjustable path for the lifeguard to patrol.
     * 
     */
    protected void returnPatrol()
    {
        turnTowards (initialX,initialY);
        move(speed);
        
        if (getX() > initialX - 5 && getX() < initialX + 5 && getY() > initialY - 5 && getY() < initialY + 5)
        {
            //             getWorld().addObject(cone, getX(), getY());
            this.setLocation (initialX, initialY);
            this.setRotation(initialRotation);
            cone.getImage().setTransparency(255);
            cone.setLocation(getX(),getY());
            cone.setRotation(180);
            this.setImage(patrol);
            returnToPatrol = false;
            whistled = false;
            //             busy = false;
            saving = false;

        }
    } 

}
