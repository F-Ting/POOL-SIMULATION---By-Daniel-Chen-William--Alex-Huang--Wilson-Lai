import greenfoot.*;

/**
 * Write a description of class StartButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StartButton extends Buttons
{
    public void clicked()
    {
        MenuWorld menuWorld = (MenuWorld) getWorld();
        menuWorld.beginSim();
    }
}
    
