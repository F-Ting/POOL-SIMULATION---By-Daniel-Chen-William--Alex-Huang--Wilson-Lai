import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The view cone class is used to detect drowining people by putting them in an array and returning the person that is drowning when touched.
 * 
 * @author (Alex) 
 * @version 1.1
 * - 1.0 (Alex)returns the person that it is touching
 * - 1.1 (Daniel)uses array to keep track of people that is touching and returns the person that is drowning
 */
public class ViewCone extends Misc
{
    private People[] drowning;
    public ViewCone()
    {
        int wide = getImage().getWidth();  
        int high = getImage().getHeight();  
        GreenfootImage base;  
        base = new GreenfootImage(wide + 300, high);  
        base.drawImage(getImage(), 300, 0);
        setImage(base);
    }

    public People inView()
    {
        int amount = getIntersectingObjects(People.class).size();
        drowning  = new People [amount];
        for (int i = 0; i < amount; i++)
        {
            drowning[i] = (People)getIntersectingObjects(People.class).get(i);
            if(drowning != null)
                if(drowning[i].getStatus() == "Drowning")
                    return drowning[i];
        }
        return null;
    }
}
