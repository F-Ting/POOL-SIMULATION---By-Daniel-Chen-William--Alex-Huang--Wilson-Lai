import greenfoot.*;

/**
 * Write a description of class NextButton2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NextButton2 extends Buttons
{
    Instruction2 page;
    
    public void clicked() 
    {
        page = (Instruction2)getOneIntersectingObject(Instruction2.class);
        getWorld().removeObject (page);
        getWorld().removeObject (this);
    }     
}
