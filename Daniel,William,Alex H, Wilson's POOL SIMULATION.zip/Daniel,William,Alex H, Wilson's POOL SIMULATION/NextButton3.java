import greenfoot.*;

/**
 * Write a description of class NextButton3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NextButton3 extends Buttons
{
    Instruction3 page;
    
    public void clicked() 
    {
        page = (Instruction3)getOneIntersectingObject(Instruction3.class);
        getWorld().removeObject (page);
        getWorld().removeObject (this);
    }      
}
