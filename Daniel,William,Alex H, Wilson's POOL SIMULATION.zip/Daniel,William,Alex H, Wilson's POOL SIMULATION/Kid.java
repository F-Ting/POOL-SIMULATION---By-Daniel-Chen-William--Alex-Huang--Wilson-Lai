import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Do what they do based on their current status and target(Described in superclass)
 * 
 * @author Daniel
* @version 1.0
*  1.0 class created
 */
public class Kid extends People
{
    public Kid()
    {
        super();
        startSpeed = 3;
        speed = startSpeed;
        stamina = 5000;
        chanceOfDrowning = 2000;
        currentStamina = stamina;
        type = "Kid";
    }

     /**
     * Spawn and updates current stamina percent as stamina decreases.
     */
    public void act() 
    {
        spawnedNotification();
        staminaPercent = (int)((double)currentStamina/stamina*100);
        checkDrown();
        if(tired())
            leave();
        if(arrived() == false)
            walk();
        else
            play();
        if (leave == false)
        {
            if(isDrowning())
                isDrowning = true;
            else 
                isDrowning = false;
        }
        checkID();
    }    
}
