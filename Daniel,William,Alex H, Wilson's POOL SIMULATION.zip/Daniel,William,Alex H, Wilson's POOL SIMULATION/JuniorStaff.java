import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Junior staff gets assigned a speed of 2 and automatically start patrolling the pool
 * If the junior staff reaches 4 certain points in the world, they will rotate so they are always facing the pool.
 * The cone of vision assigned to each junior staff also follows each junior staff.
 * 
 * @author (Wilson) 
 * @version 1.0
 * -1.1 guard Class created (Wilson)
 * -1.2 cone of vision set to follow lifguard (Alex)
 */
public class JuniorStaff extends LifeGuard
{
    private int offsetX = 165;
    private int offsetY = 0;

    public JuniorStaff(int guardSpeed)
    {
        patrol = getImage();
        
        //Glow around lifeguard makes them easier to see
        rescue = new GreenfootImage("glowJ.png");
        
        //All speed values are assigned here
        startSpeed = 2;
        speed = startSpeed;
        swimSpeed = guardSpeed;
    }

    /**
     * Act - do whatever the JuniorStaff wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //If a lifeguard is set to be spawned, but has not been yet, they will spawn
        if (spawned == false) spawned();

        //If a lifeguard is set to return to patrol, then they will return to patrol
        if (returnToPatrol == true) returnPatrol();
        checkDrown();
        
        //If they are not saving anyone, lifeguards will continue to guard
        if(!saving)
            guard();
    }    

    private void guard()
    {
        move(speed);
        //If the junior staff reaches one of 4 points, they will rotate so they are always facing the pool
        //Cone of vision always follows the lifeguard's point of view
        if(this.getX() == 800 && this.getY() == 160)
        {
            this.setRotation(90);
            cone.setRotation(180);

            offsetX = 0;
            offsetY = 0;
        } else if(this.getX() == 800 && this.getY() == 460)
        {
            this.setRotation(180);
            cone.setRotation(270);

            offsetX = 0;
            offsetY = 0;
        } else if(this.getX() == 18 && this.getY() == 460)
        {
            this.setRotation(270);
            cone.setRotation(0);

            offsetX = 0;
            offsetY = 0;
        } else if(this.getX() == 18 && this.getY() == 160)
        {
            this.setRotation(0);
            cone.setRotation(90);

            offsetX = 0;
            offsetY = 0;            
        }

        cone.setLocation (getX()+offsetX, getY()+offsetY);
    }

}
