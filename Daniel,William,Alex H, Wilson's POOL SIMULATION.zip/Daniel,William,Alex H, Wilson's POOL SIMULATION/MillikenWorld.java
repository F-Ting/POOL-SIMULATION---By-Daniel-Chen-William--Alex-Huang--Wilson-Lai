import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * 
 * This world is a SWIMMING POOL!!!! YAY.
 * So this world is in charge of spawning people and establishing the pool objects in place.
 * 
 * @author 
 * @version 1.1
 * - 1.0 (Daniel) Class created;
 * - 1.1 (Daniel) people spawning, time and reputation display, newsfeedisplay
 */
public class MillikenWorld extends World
{
    private int actCounter;
    private int randomize;

    private int peopleSpawnRate = 800;
    private int startRep;
    private int guardAmount;
    private int guardSpeed;

    private Chair chair;
    private Board board;
    private Time time;
    private RepDisplay reputation;
    private Newsfeed news;
    private HotTub ht;
    private Pool p;
    private ChangeRoom c;
    private Board b;
    private ObjectInfo o;
    private JuniorStaff js;
    private SeniorStaff ss;
    GreenfootSound backgroundMusic = new GreenfootSound("OSTpool.mp3");

    /**
     * Constructor for objects of class Pool.
     * 
     */
    public MillikenWorld(int guardSpeed,int guardAmount,int repPercent)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.

        super(860, 560, 1);
        setPaintOrder(ChangeRoom.class, SeniorStaff.class, Chair.class, JuniorStaff.class, People.class,Misc.class, JustImages.class, PoolObjects.class);
        setActOrder(ObjectInfo.class,People.class);
        time = new Time();

        startRep = repPercent;
        this.guardAmount = guardAmount;
        this.guardSpeed = guardSpeed;

        reputation = new RepDisplay(100, startRep);
        news = new Newsfeed();
        ht = new HotTub(7);
        c = new ChangeRoom();
        b = new Board(3);
        p = new Pool(50);
        o = new ObjectInfo();
        chair = new Chair();

        ss = new SeniorStaff(guardSpeed);

        addObject(chair, 800,405);
        addObject(ss, 785,397);
        addObject(p, 390,310);
        addObject(b, 720,300);
        addObject(c, 500, 22);
        addObject(ht , 150, 80);
        addObject(o , 760, 510);
        addObject(reputation, 700,30);
        addObject(time,800,30);
        addObject(news, 100, 510);

        backgroundMusic.play();
    }

    /**
     * spawn people and lifeguards
     * 
     */
    public void act()
    {
        actCounter ++;
        randomize = Greenfoot.getRandomNumber(peopleSpawnRate - reputation.getPercentage()*7);
        if(guardAmount > 0)
        {
            if(actCounter > 300)
            {
                addObject (new JuniorStaff(guardSpeed), 798,160);
                guardAmount --;
                actCounter = 0;
            }
        }

        if (randomize == 1)
        {
            // spawn a kid
            addObject (new Kid(), 500,0);
        }
        else if (randomize == 2)
        {
            // spawn an elder
            addObject (new Elder(), 500,0);
        }

        else if (randomize == 3)
        {
            // spawn an adult
            addObject (new Adult(),500,0);
        }
        if(reputation.getReputation() == 0)
            endGame();
    }

    
    /**
     * Updates the Newsfeed display box with the input string.
     * @return actCount the number of act.
     * 
     */
    public int getActCount()
    {
        return actCounter;
    }

    /**
     * Updates the Newsfeed display box with the input string.
     * @param event the even that is happening
     * 
     */
    public void updateNews(String event)
    {
        news.update(event);
    }

    public void updateReputation(int amount)
    {
        reputation.update(amount);
    }

    private void endGame()
    {
        EndWorld e = new EndWorld();
        backgroundMusic.stop();
        Greenfoot.setWorld(e);
    }
}

