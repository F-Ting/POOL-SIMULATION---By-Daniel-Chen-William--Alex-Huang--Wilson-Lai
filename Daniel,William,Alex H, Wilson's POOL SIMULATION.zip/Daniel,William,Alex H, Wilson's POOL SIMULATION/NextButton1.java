import greenfoot.*;

/**
 * Write a description of class NextButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NextButton1 extends Buttons
{
    Instruction1 page;
    
    public void clicked() 
    {
        page = (Instruction1)getOneIntersectingObject(Instruction1.class);
        getWorld().removeObject (page);
        getWorld().removeObject (this);
    }    
}
