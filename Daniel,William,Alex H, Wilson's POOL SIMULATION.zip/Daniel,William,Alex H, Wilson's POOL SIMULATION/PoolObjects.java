import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Pool objects all have maxCapacitys that the currentAmount can`t go over
 * 
 * @author (Daniel)
 * @version 1.2
 * - 1.0 created basic class components (max, cur, permission)
 * - 1.1 added accessors 
 * - 1.2 (William) added array of to store occupants 
 */
public abstract class PoolObjects extends Actor
{
    protected int maxCapacity;
    protected int currentAmount;
    protected boolean permission;
    protected People[] pList;

    /**
     * Creating pool obejcts sets the maxCapacity to the input and sets array list accordingly.
     * 
     * @param limit maximum capacity of the pool object
     */
    public PoolObjects(int limit)
    {
        maxCapacity = limit;
        pList = new People[maxCapacity];
        for(int i = 0;i<maxCapacity;i++){
            pList[i] = null;
        }
        permission = true;
    }

    /**
     * Adds the input to the array of this object.
     * 
     * @param p People object that is added to the array
     */
    public void addToList(People p)
    {
        boolean added = false;
        int i = 0;
        while(!added){
            if(pList[i] == null){
                pList[i] = p;
                added = true;
            } 
            i++;
            if(i == maxCapacity){
                added = true;
            }
        }
    }

    /**
     * Removes the input from the array of this object.
     * 
     * @param p People object that is removed from the array
     */
    public void removeFromList(People p)
    {
        boolean removed = false;
        int i = 0;
        while(!removed){
            if(pList[i] == p){
                pList[i] = null;
                removed = true;
            }
            i++;
            if(i == maxCapacity){
                removed = true;
            }
        }
    }

    /**
     * updates currentAmount to the current amount of People in this Object.
     */
    protected abstract void  getCurrentAmount();

    /**
     * checks if this object is full and if it is will change permission accordingly.
     */
    protected void checkFull()
    {
        if (currentAmount >= maxCapacity)                 //if limit is reached
        {
            permission = false;             // no more ppl are allowed inside
        }
        else permission = true;
    }

    /**
     * Gets if this object can hold any more objects.
     * 
     * @return permission
     */
    public boolean getAccess()
    {
        return permission;
    }

    /**
     * returns width of this object.
     * 
     * @return width of object
     */
    public int getWidth()
    {
        return getImage().getWidth();
    }
}
