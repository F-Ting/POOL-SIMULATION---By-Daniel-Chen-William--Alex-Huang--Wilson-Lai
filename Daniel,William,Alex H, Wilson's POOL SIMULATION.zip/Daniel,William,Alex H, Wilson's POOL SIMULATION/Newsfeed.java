import greenfoot.*;
import java.awt.Color;
import java.awt.Font;

import java.util.Scanner;
/**
 * Write a description of class Newsfeed here.
 * 
 * @author William 
 * @version 1.3
 * - 1.0 (William) class is made
 * - 1.1 (Daniel & William) removed starting text
 * - 1.2 (William) made text involving drowning appear red
 * - 1.3 (Alex) added a new color into text display
 */
public class Newsfeed extends HUD
{
    private int maxY = 100;     //dimensions
    private int maxX = 200;
    private String[] newsLines;     //array of stored text
    private GreenfootImage textBox; //canvas
    private Color textBoxColor = new Color(0,0,0,75);
    private Color textColor = Color.WHITE;
    private int offset = 20;                        //displacement of each line
    private Font textFont = new Font ("Compact",Font.BOLD, 17);
    private int actsToFade = 200;               //number tilFade has to reach before fading
    private int tilFade = 0;                    //counter for time until fading
    private int transparency = 255;             //transparency 0-255
    private boolean fade = false;               //defaults to not fading

    /**
     * Constructs a news feed box of preset dimensions designed to hold 5 lines of text. 
     */
    public Newsfeed()
    {
        //sets backdrop and size
        textBox = new GreenfootImage (maxX,maxY);
        textBox.setColor(textBoxColor);
        textBox.fill();

        //sets text color and font and writes "" for all lines at the start to avoid nulls
        textBox.setFont(textFont);
        textBox.setColor(textColor);
        newsLines = new String[5];
        for(int i = 0;i<5;i++){
            newsLines[i] = "";
            textBox.drawString(newsLines[i],2,maxY-4-i*offset);
        }

        this.setImage(textBox);
    }

    /**
     * Constructs a news feed box of preset dimensions designed to hold 5 lines of text with or without set ability to fade.
     * 
     * @param fade if true will allow this object to fade from view
     */
    public Newsfeed(boolean fade)
    {
        this();
        this.fade = fade;
    }

    /**
     * Adds a new line of text to the news feed at the bottom most line and shifts all existing lines up by one.
     * 
     * @param event string used as new inputed text
     */
    public void update(String event)
    {
        clearCanvas();

        for(int i = 4;i>0;i--){
            newsLines[i] = newsLines[i-1];
        }
        newsLines[0] = event;
        for(int i = 0;i<5;i++){
            if(newsLines[i].indexOf("drowned") >= 0){
                textBox.setColor(Color.RED);
            }
            else if(newsLines[i].indexOf("safe") >= 0){
                textBox.setColor(Color.GREEN);
            }
            else{
                textBox.setColor(Color.WHITE);
            }
            textBox.drawString(newsLines[i],2,maxY-4-i*offset);
        }
    }

    /**
     * Resets the image of this object to a blank box of transparent backdrop.
     */
    private void clearCanvas()
    {
        textBox.clear();
        textBox.setColor(textBoxColor);
        textBox.fill();

        textBox.setColor(textColor);
    }

    /**
     * Changes the boolean that controls ability to fade.
     */
    private void changeFade()
    {
        if(fade){
            fade = false;
        }else{
            fade = true;
        }
    }

    /**
     * Resets counter until fade.
     */
    public void resetFade()
    {
        tilFade = 0;
    }

    /**
     * Gets boolean for ability to fade
     * 
     * @return true if has ability to fade, false if not
     */
    public boolean getFade()
    {
        return fade;
    }

    /**
     * Depending on ability to fade will fade after interval of time being idle, interval of time resets if mouse has been
     * moved over this object and ability to fade can be toggled by clicking this object.
     */
    public void act()
    {
        //allows for fade will add one to tilFade every act until it reaches actsToFade where transparency will begin to
        //go down. Reseting tillFade automatically resets trancparency.
        if(fade){
            if(tilFade < actsToFade){
                tilFade++;
                transparency = 255;
            }else{
                if(transparency > 1){
                    transparency -= 2;
                }
            }

            if(Greenfoot.mouseMoved(this)){
                resetFade();
            }
        }
        if(Greenfoot.mousePressed(this)){
            changeFade();
        }
        textBox.setTransparency(transparency); 
    }
}