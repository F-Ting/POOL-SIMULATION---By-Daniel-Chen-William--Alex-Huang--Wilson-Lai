import greenfoot.*;

/**
 * Write a description of class MinusSpeed here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MinusSpeed extends Buttons
{
    /**
     * Act - do whatever the MinusSpeed wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void clicked()
    {   
        MenuWorld menuWorld = (MenuWorld) getWorld();
        menuWorld.changeSpeed(false);
    }
}
