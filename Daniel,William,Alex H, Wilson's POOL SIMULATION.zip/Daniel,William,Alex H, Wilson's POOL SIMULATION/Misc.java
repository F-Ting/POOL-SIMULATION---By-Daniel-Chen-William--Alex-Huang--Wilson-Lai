import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Little animated images and modular methods for the simulation
 * 
 * @author (Daniel) 
 * @version (1.0)
 * 1.0 class was created
 */
public class Misc extends Actor
{
    /**
     * Act - do whatever the Misc wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
